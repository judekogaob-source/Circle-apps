# Circle Android APK project

This project packages the Circle HTML app in an Android app using Capacitor.

## Build requirements
- A computer (Windows, macOS, or Linux)
- Node.js 22 or newer
- Android Studio and an Android SDK

## Build an APK
1. Extract this ZIP.
2. Open a terminal in the extracted `circle_android_project` folder.
3. Install dependencies:
   `npm install`
4. Add the Android project:
   `npx cap add android`
   If the `android` folder already exists, skip this step.
5. Sync the HTML app into Android:
   `npx cap sync android`
6. Open Android Studio:
   `npx cap open android`
7. Wait for Gradle sync to finish. In Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. Android Studio will show where the APK was saved. The usual debug APK path is:
   `android/app/build/outputs/apk/debug/app-debug.apk`

## Install on your phone
Transfer `app-debug.apk` to your Android phone, open it, and allow installation from that source if Android asks. Only install APKs you built or trust.

## Notes
- The app's current data uses browser localStorage, so data is stored locally on that installation and is not a shared online database.
- The demo login credentials are not secure. Do not use real passwords or private data.
- Photo picking and storage behavior should be tested on the target device. A production release should add secure authentication, a server database, access rules, and proper photo storage.
- For a Play Store release, generate a signed release build and follow current Google Play requirements.
